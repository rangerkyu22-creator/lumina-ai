package com.example.luminaai

import android.content.ContentValues
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import java.util.concurrent.Executors
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

class MainActivity : ComponentActivity() {

    private val worker = Executors.newSingleThreadExecutor()
    private lateinit var preview: ImageView
    private lateinit var status: TextView
    private lateinit var enhanceButton: Button
    private lateinit var saveButton: Button
    private var originalBitmap: Bitmap? = null
    private var enhancedBitmap: Bitmap? = null

    private val imagePicker = registerForActivityResult(
        ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) loadImage(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildScreen()
    }

    private fun buildScreen() {
        val background = 0xFF0B1020.toInt()
        val panel = 0xFF151D32.toInt()
        val accent = 0xFF8B5CF6.toInt()

        val scroll = ScrollView(this).apply {
            setBackgroundColor(background)
            isFillViewport = true
        }
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(26), dp(20), dp(24))
        }

        val brand = TextView(this).apply {
            text = "✦  LUMINA AI"
            textSize = 27f
            setTextColor(Color.WHITE)
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        }
        content.addView(brand)

        content.addView(TextView(this).apply {
            text = "PHOTO ENHANCER  •  HD RESTORATION"
            textSize = 11f
            letterSpacing = 0.12f
            setTextColor(0xFFAAA8C7.toInt())
            setPadding(0, dp(5), 0, dp(20))
        })

        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(12), dp(12), dp(12), dp(12))
            setBackgroundColor(panel)
        }
        preview = ImageView(this).apply {
            adjustViewBounds = true
            scaleType = ImageView.ScaleType.FIT_CENTER
            minimumHeight = dp(230)
            setBackgroundColor(0xFF202A43.toInt())
            setImageResource(android.R.drawable.ic_menu_gallery)
        }
        card.addView(preview, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, dp(300)
        ))
        content.addView(card, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ))

        status = TextView(this).apply {
            text = "Pilih foto untuk mulai meningkatkan kualitas."
            textSize = 13f
            setTextColor(0xFFD0D5E5.toInt())
            setPadding(2, dp(14), 2, dp(14))
        }
        content.addView(status)

        val pickButton = makeButton("PILIH FOTO", accent)
        content.addView(pickButton, matchWidth())
        pickButton.setOnClickListener {
            imagePicker.launch(
                androidx.activity.result.PickVisualMediaRequest(
                    ActivityResultContracts.PickVisualMedia.ImageOnly
                )
            )
        }

        enhanceButton = makeButton("✨  ENHANCE HD 2X", 0xFF2563EB.toInt()).apply {
            isEnabled = false
            alpha = 0.5f
        }
        content.addView(enhanceButton, buttonParams())
        enhanceButton.setOnClickListener { enhancePhoto() }

        saveButton = makeButton("SIMPAN KE GALERI", 0xFF0F9D78.toInt()).apply {
            isEnabled = false
            alpha = 0.5f
        }
        content.addView(saveButton, buttonParams())
        saveButton.setOnClickListener { savePhoto() }

        content.addView(TextView(this).apply {
            text = "Tips: gunakan foto asli dengan resolusi terbaik. Hasil 2x memperbesar ukuran gambar dan menambah ketajaman, tetapi bukan AI generatif yang bisa menciptakan detail wajah baru."
            textSize = 11f
            setTextColor(0xFF929BB2.toInt())
            setPadding(2, dp(20), 2, 0)
        })
        scroll.addView(content)
        setContentView(scroll)
    }

    private fun loadImage(uri: Uri) {
        status.text = "Membuka foto..."
        worker.execute {
            try {
                val bitmap = decodeSampledBitmap(uri, 1600)
                runOnUiThread {
                    originalBitmap = bitmap
                    enhancedBitmap = null
                    preview.setImageBitmap(bitmap)
                    status.text = "Foto siap • ${bitmap.width} × ${bitmap.height}px"
                    enhanceButton.isEnabled = true
                    enhanceButton.alpha = 1f
                    saveButton.isEnabled = false
                    saveButton.alpha = 0.5f
                }
            } catch (e: Exception) {
                runOnUiThread {
                    status.text = "Foto gagal dibuka. Coba pilih gambar lain."
                    toast("Tidak dapat membuka foto.")
                }
            }
        }
    }

    private fun decodeSampledBitmap(uri: Uri, maxSide: Int): Bitmap {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        contentResolver.openInputStream(uri).use { input ->
            BitmapFactory.decodeStream(input, null, bounds)
        }
        var sample = 1
        while (max(bounds.outWidth / sample, bounds.outHeight / sample) > maxSide) {
            sample *= 2
        }
        val options = BitmapFactory.Options().apply {
            inSampleSize = sample
            inPreferredConfig = Bitmap.Config.ARGB_8888
        }
        return contentResolver.openInputStream(uri).use { input ->
            BitmapFactory.decodeStream(input, null, options)
        } ?: throw IllegalStateException("Bitmap kosong")
    }

    private fun enhancePhoto() {
        val source = originalBitmap ?: return
        enhanceButton.isEnabled = false
        status.text = "Sedang meningkatkan foto..."
        worker.execute {
            try {
                val result = enhance2x(source)
                runOnUiThread {
                    enhancedBitmap = result
                    preview.setImageBitmap(result)
                    status.text = "Selesai • ${result.width} × ${result.height}px • Enhanced 2x"
                    enhanceButton.isEnabled = true
                    saveButton.isEnabled = true
                    saveButton.alpha = 1f
                }
            } catch (e: OutOfMemoryError) {
                runOnUiThread {
                    status.text = "Memori HP tidak cukup untuk memproses foto ini."
                    enhanceButton.isEnabled = true
                    toast("Coba foto dengan ukuran lebih kecil.")
                }
            } catch (e: Exception) {
                runOnUiThread {
                    status.text = "Gagal memproses foto."
                    enhanceButton.isEnabled = true
                }
            }
        }
    }

    // Upscale 2x, lalu lakukan penajaman ringan berbasis tetangga piksel.
    private fun enhance2x(source: Bitmap): Bitmap {
        val width = source.width * 2
        val height = source.height * 2
        require(width <= 3200 && height <= 3200) { "Gambar terlalu besar" }

        val scaled = Bitmap.createScaledBitmap(source, width, height, true)
        val pixels = IntArray(width * height)
        scaled.getPixels(pixels, 0, width, 0, 0, width, height)
        val output = pixels.copyOf()

        for (y in 1 until height - 1) {
            for (x in 1 until width - 1) {
                val i = y * width + x
                val c = pixels[i]
                val l = pixels[i - 1]
                val r = pixels[i + 1]
                val u = pixels[i - width]
                val d = pixels[i + width]

                fun sharpen(channel: (Int) -> Int): Int {
                    val center = channel(c).toFloat()
                    val average = (channel(l) + channel(r) + channel(u) + channel(d)) / 4f
                    return (center + 0.55f * (center - average)).roundToInt().coerceIn(0, 255)
                }

                output[i] = Color.argb(
                    Color.alpha(c),
                    sharpen(Color::red),
                    sharpen(Color::green),
                    sharpen(Color::blue)
                )
            }
        }

        val result = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        result.setPixels(output, 0, width, 0, 0, width, height)
        if (scaled !== source) scaled.recycle()
        return result
    }

    private fun savePhoto() {
        val bitmap = enhancedBitmap ?: return
        status.text = "Menyimpan foto..."
        worker.execute {
            try {
                val name = "LUMINA_HD_${System.currentTimeMillis()}.jpg"
                val values = ContentValues().apply {
                    put(MediaStore.Images.Media.DISPLAY_NAME, name)
                    put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/LuminaAI")
                        put(MediaStore.Images.Media.IS_PENDING, 1)
                    }
                }
                val uri = contentResolver.insert(
                    MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values
                ) ?: throw IllegalStateException("Gagal membuat file")
                contentResolver.openOutputStream(uri)?.use { output ->
                    if (!bitmap.compress(Bitmap.CompressFormat.JPEG, 95, output)) {
                        throw IllegalStateException("Gagal mengompres foto")
                    }
                } ?: throw IllegalStateException("Output kosong")

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    val done = ContentValues().apply {
                        put(MediaStore.Images.Media.IS_PENDING, 0)
                    }
                    contentResolver.update(uri, done, null, null)
                }
                runOnUiThread {
                    status.text = "Foto tersimpan di Pictures/LuminaAI"
                    toast("Berhasil disimpan ke galeri!")
                }
            } catch (e: Exception) {
                runOnUiThread {
                    status.text = "Gagal menyimpan foto."
                    toast("Tidak dapat menyimpan foto.")
                }
            }
        }
    }

    private fun makeButton(label: String, color: Int) = Button(this).apply {
        text = label
        textSize = 14f
        isAllCaps = false
        setTextColor(Color.WHITE)
        setBackgroundTintList(android.content.res.ColorStateList.valueOf(color))
    }

    private fun matchWidth() = LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.MATCH_PARENT, dp(52)
    )

    private fun buttonParams() = LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.MATCH_PARENT, dp(52)
    ).apply { topMargin = dp(10) }

    private fun dp(value: Int): Int =
        (value * resources.displayMetrics.density).roundToInt()

    private fun toast(message: String) =
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()

    override fun onDestroy() {
        super.onDestroy()
        worker.shutdown()
    }
}

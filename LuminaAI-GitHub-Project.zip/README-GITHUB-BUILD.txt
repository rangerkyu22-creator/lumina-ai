LUMINA AI - GitHub APK build
1. Extract this ZIP on your Android phone.
2. In your GitHub repository, use Add file > Upload files.
3. Upload the extracted project contents (including the .github folder), not the ZIP file itself.
4. Commit the upload to the main branch.
5. Open Actions > Build LUMINA AI APK and wait for the run to finish.
6. Download the LUMINA-AI-debug-apk artifact, extract it, and install app-debug.apk.
